<?php
require_once $_SERVER["DOCUMENT_ROOT"]."/config.php";
require_once $_SERVER["DOCUMENT_ROOT"]."/xshop/config.php";
//引入云打印
require_once($_SERVER["DOCUMENT_ROOT"].'/xshop/print.yun.class.php');

$Z = new CONFIG;
if(!isset($_POST['id'])){
	exit($Z->aJson(0,'支付成功1'));
}
//设置发送订单提醒到店主标志为真
$sendMSG2Admin = true;

$id = intval($_POST['id']);//会员id

//把成功的数据写入数据库保存起来以供查询

//主动通知，什么也不做，返回成功即可
/*
$now = time();
if($Z->____updateField("cz_order","set status='1',updatetime='$now' where status=0 and out_trade_no='{$_POST['wxoid']}' ;")){
	$d = $Z->_getOneBy("cz_order","out_trade_no",$_POST['wxoid']);
	//CONFIG::errorLog(var_export($d,1),'zfb-log.sql');
	$user = $Z->_getOneBy("member","id",$d['member_id']);
	//更新用户余额
	$Z->____updateField("member","set `yue`=`yue`+{$d['jine']},updatetime='$now' where id='{$user['id']}';");
}
*/
exit($Z->aJson(1,'支付成功'));
?>