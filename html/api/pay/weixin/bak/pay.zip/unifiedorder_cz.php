<?php
if(!isset($_SESSION)){
	session_start();
}
ini_set('date.timezone','Asia/Shanghai');
//error_reporting(E_ERROR);
require_once $_SERVER["DOCUMENT_ROOT"]."/config.php";
require_once $_SERVER["DOCUMENT_ROOT"]."/setting_pay.php";
require_once $_SERVER["DOCUMENT_ROOT"]."/xshop/config.php";
//加载用户店铺配置
$_SESSION['shopConfig'] = get_a_shop_set_by_shopid();

//判断是否使用平台的支付接口
if($_SESSION['shopConfig']['USE_PLATEFORM_WX']==1){
	$tmpSeting = SETTINGPAY();
	$_SESSION['shopConfig'] = array(
		'WXPAY_SECRET' => $tmpSeting['WXPAY_APPSECRET'],
		'WXPAY_APPID' => $tmpSeting['WXPAY_APPID'],
		'WXPAY_MCHID' => $tmpSeting['WXPAY_MCHID'],
		'WXPAY_KEY' => $tmpSeting['WXPAY_KEY']
		);
}else{
	//修复少了几个字符的appsecret
	$_SESSION['shopConfig']['WXPAY_SECRET'] = $_SESSION['shopConfig']['WXPAY_APPSECRET'];
}

require_once "lib/WxPay.Api.php";
require_once "unit/WxPay.JsApiPay.php";
require_once 'unit/log.php';

$Z = new CONFIG;
//注意正式环境请设置下面
$WXPAYDIR = 'WxpayAPI'; ##正式环境
//$WXPAYDIR = 'WxpayAPITest'; ##测试环境

//初始化日志
$logHandler= new CLogFileHandler("./logs/".date('Y-m-d').'.log');
$log = Log::Init($logHandler, 15);

//获取用户openid
$tools = new JsApiPay();
$openId = $tools->GetOpenid();
//统一下单
if(!$openId){
	$Z->attention('该页面已失效，请重新下单');
}




$input = new WxPayUnifiedOrder();
$input->SetBody("会员充值|".$_SESSION['shopConfig']['shopname'].'|￥'.$_GET['jine'].'|店铺ID:'.$_GET['shopid'].'|会员ID:'.$_GET['id']);//商品或支付单简要描述4
$unique_id = md5(intval($_GET['id']).time());
$input->SetAttach($unique_id);//附加数据，在查询API和支付通知中原样返回，该字段主要用于商户携带订单的自定义数据
$input->SetOut_trade_no(WxPayConfig::MCHID().date("YmdHis"));
$input->SetTotal_fee($_GET['jine']*100);//单位：分
$input->SetTime_start(date("YmdHis"));
$input->SetTime_expire(date("YmdHis", time() + 600));
$input->SetGoods_tag('会员充值,ID'.$_GET['id']);//商品标记，代金券或立减优惠功能的参数
$input->SetNotify_url("http://".$_SERVER["HTTP_HOST"]."/xshop/".$WXPAYDIR."/notify_cz.php");//异步通知地址
$input->SetTrade_type("JSAPI");
$input->SetOpenid($openId);

//===============中远科技==============
//先写入订单

$cid = $Z->___add("cz_order",array(
	"out_trade_no"=>$unique_id,
	"paytype"=>"wx",
	"addtime"=>time(),
	"jine"=>floatval($_GET['jine']),
	"shopid"=>intval($_GET['shopid']),
	"user_id"=>intval($_GET['adminid']),
	"member_id"=>intval($_GET['id']),
	"status"=>0
	));
if(!$cid){
	header("content-type: text/html;charset=utf-8");
	exit("充值记录表不存在");
}
//===============中远科技==============



$order = WxPayApi::unifiedOrder($input);
$jsApiParameters = $tools->GetJsApiParameters($order);
//file_put_contents('order'.time(),var_export($jsApiParameters,true));
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=0">
        <title>微信支付</title>
        <link rel="stylesheet" href="/xshop/migrate/dist/style/weui.min.css"/>
        <link rel="stylesheet" href="/xshop/migrate/dist/style/example.css"/>
        <script type="text/javascript">
        	var queryStr = "<?php echo $url;?>";
        </script>
        <script src="/xshop/migrate/dist/js/zepto.min.js"></script>
    	<script src="/xshop/migrate/dist/js/memberCharge.js"></script>
    	
    	<script type="text/javascript">
			//调用微信JS api 支付
			function jsApiCall()
			{
				WeixinJSBridge.invoke(
					'getBrandWCPayRequest',
					<?php echo $jsApiParameters; ?>,
					function(res){
						if(res.err_msg == "get_brand_wcpay_request:ok") {
							$.ajax({
						        type: "POST",
						        url: "call_back_url_cz.php",
						        dataType: "json",
						        data: {id:'<?php echo intval($_GET['id']);?>',wxoid:'<?php echo $unique_id;?>'},
						        cache: !1,
						        success: function(a) {
						        	$('#pay').attr('disabled','true');
						        	$('#pay').html(a.msg);
						        	$('#pay').css('background-color', 'gray');
						            //window.history.go(-1);
						        },
						        error: function() {
						            alert('网络连接失败了');
						        }
						    })	
						}else{
							alert(res.err_msg);
						}
					}
				);
			}

			function callpay()
			{

				if (typeof WeixinJSBridge == "undefined"){
				    if( document.addEventListener ){
				        document.addEventListener('WeixinJSBridgeReady', jsApiCall, false);
				    }else if (document.attachEvent){
				        document.attachEvent('WeixinJSBridgeReady', jsApiCall); 
				        document.attachEvent('onWeixinJSBridgeReady', jsApiCall);
				    }
				}else{
				    jsApiCall();
				}
			}

			function goback(){
				window.history.go(-1);
			}
		</script>
    </head>
    <body ontouchstart>
    <div class="container js_container">
    </div>

    <script type="text/html" id="tpl_login_dialog">
        <div class="page" style="overflow: hidden">
            <div class="hd">
                <h1 class="page_title">会员安全充值</h1>
            </div>
            

            <div class="weui_cells_title">会员充值享受更多优惠哟</div>
	        <div class="weui_cells weui_cells_form">
	            <div class="weui_cell">
	                <div class="weui_cell_hd"><label class="weui_label">总额￥</label></div>
	                <div class="weui_cell_bd weui_cell_primary">
	                    <input class="weui_input" value="<?php echo floatval($_GET['jine']);?>" readonly />
	                </div>
	            </div>
	            
	        </div>
            
	        <div class="weui_btn_area">
	            <a class="weui_btn weui_btn_primary" id="pay">微信安全支付</a>
	            <a class="weui_btn weui_btn_warn" id="backshop">返回</a>
	        </div>
            
	        <div id="toast" style="display: none;">
		        <div class="weui_mask_transparent"></div>
		        <div class="weui_toast">
		            <i class="weui_icon_toast"></i>
		            <p class="weui_toast_content" id="loginMsg">OK</p>
		        </div>
		    </div>
            
        </div>
    </script>
</body>
</html>