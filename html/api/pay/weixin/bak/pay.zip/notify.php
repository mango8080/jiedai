<?php
if(!isset($_SESSION)){
	session_start();
}
ini_set('date.timezone','Asia/Shanghai');
error_reporting(0);
require_once $_SERVER["DOCUMENT_ROOT"]."/config.php";
require_once $_SERVER["DOCUMENT_ROOT"]."/xshop/config.php";


//读取店铺设置开始
$WX_RET_DATA = json_decode(json_encode(simplexml_load_string($GLOBALS['HTTP_RAW_POST_DATA'], 'SimpleXMLElement', LIBXML_NOCDATA)), true);
$wxoid = $WX_RET_DATA['attach'];
$Z = new CONFIG;
$order = $Z->_getOneBy('order','wxoid',$wxoid);
$_SESSION['shopConfig'] = getShopsetByOrder($order);
//file_put_contents(dirname(__FILE__)."/logs/notify-recieved.".time().".txt", var_export($WX_RET_DATA,1));
//file_put_contents(dirname(__FILE__)."/logs/notify-order.".time().".txt", var_export($order,1));
//file_put_contents(dirname(__FILE__)."/logs/notify-shopConfig.".time().".txt", var_export($_SESSION['shopConfig'],1));
//读取店铺设置结束


require_once "lib/WxPay.Api.php";
require_once 'lib/WxPay.Notify.php';
require_once 'unit/log.php';

//初始化日志
$logHandler= new CLogFileHandler("./logs/".date('Y-m-d').'.log');
$log = Log::Init($logHandler, 15);

class PayNotifyCallBack extends WxPayNotify
{
	//查询订单
	public function Queryorder($transaction_id)
	{
		$input = new WxPayOrderQuery();
		$input->SetTransaction_id($transaction_id);
		$result = WxPayApi::orderQuery($input);
		//Log::DEBUG("queryOrderAfterPaid:" . json_encode($result));
		if(array_key_exists("return_code", $result)
			&& array_key_exists("result_code", $result)
			&& $result["return_code"] == "SUCCESS"
			&& $result["result_code"] == "SUCCESS")
		{
			return true;
		}
		return false;
	}
	
	//重写回调处理函数
	public function NotifyProcess($data, &$msg)
	{
		//Log::DEBUG("call back:" . json_encode($data));
		$notfiyOutput = array();
		
		if(!array_key_exists("transaction_id", $data)){
			$msg = "输入参数不正确:".var_export($data,1);
			Log::DEBUG($msg);
			return false;
		}
		//查询订单，判断订单真实性
		if(!$this->Queryorder($data["transaction_id"])){
			$msg = "订单查询失败:".var_export($data,1);
			Log::DEBUG($msg);
			return false;
		}
		//更新数据
		$Z = new CONFIG;
		$orderInfo = $Z->_getOneBy("order",'wxoid',$data["attach"]);
		$shopInfo = $Z->_getOneBy("shop_set","shopid",$orderInfo["shopid"]);
		$now = time();
		$able_tx = intval($shopInfo["USE_PLATEFORM_WX"]);
		$wxindex = $data["transaction_id"];
		$wxoid = $data["attach"];

		if($Z->____updateField('order',"set ordertype=2,wxpaid=1,DZ_ABLE_TX={$able_tx},wxindex='{$wxindex}',updatetime={$now} where wxoid='{$wxoid}' and wxpaid=0")){
			//如果有优惠券，就更新下
			if($orderInfo['coupon_id']){
				$Z->____updateField('coupon_order',"set overtime='0',addtime='$now' where id='{$orderInfo['coupon_id']}' and overtime<>0 limit 1");
			}
			//微信通知.没有改变状态就通知，否则不通知，避免重复通知
			file_get_contents('http://'.$_SERVER["HTTP_HOST"]."/xshop/order.done.php?id={$orderInfo['id']}&adminid={$orderInfo["user_id"]}&shopid={$orderInfo["shopid"]}");
			return true;
		}else{
			$msg = "更新订单失败:".var_export($data,1);
			Log::DEBUG($msg);
			return false;
		}
	
		return true;
	}
}

//Log::DEBUG("begin notify");
$notify = new PayNotifyCallBack();
$notify->Handle(false);
?>