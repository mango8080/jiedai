<?php
require_once $_SERVER["DOCUMENT_ROOT"]."/config.php";
require_once $_SERVER["DOCUMENT_ROOT"]."/xshop/config.php";
//引入云打印
require_once($_SERVER["DOCUMENT_ROOT"].'/xshop/print.yun.class.php');

$Z = new CONFIG;
if(!isset($_POST['id'])){
	exit($Z->aJson(0,'支付成功1'));
}

exit($Z->aJson(1,'支付成功'));
//重新改进，下面的无效了。直接返回，由notify发送消息执行后续之事


//设置发送订单提醒到店主标志为真
$sendMSG2Admin = true;

$id = intval($_POST['id']);
$orderInfo = $Z->_getOneBy("order",'id',$id);
$shopInfo = $Z->_getOneBy("shop_set","shopid",$orderInfo["shopid"]);


$able_tx = intval($shopInfo["USE_PLATEFORM_WX"]);
$now = time();
if($Z->____updateField('order',"set ordertype=2,wxpaid=1,DZ_ABLE_TX={$able_tx},updatetime={$now} where id='$id' and wxpaid=0")){
	//如果有优惠券，就更新下
	if($orderInfo['coupon_id']){
		$Z->____updateField('coupon_order',"set overtime='0',addtime='$now' where id='{$orderInfo['coupon_id']}' and overtime<>0 limit 1");
	}
	//微信通知.没有改变状态就通知，否则不通知，避免重复通知
	$_SESSION['appconfig']['shopadmin']['id'] = $orderInfo["user_id"];
	file_get_contents('http://'.$_SERVER["HTTP_HOST"]."/xshop/order.done.php?id={$orderInfo['id']}&adminid={$orderInfo["user_id"]}&shopid={$orderInfo["shopid"]}");
	exit($Z->aJson(1,'支付成功咯'));
}else{
	exit($Z->aJson(1,'支付成功啦'));
}
?>