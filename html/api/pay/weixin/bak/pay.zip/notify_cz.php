<?php
if(!isset($_SESSION)){
	session_start();
}
ini_set('date.timezone','Asia/Shanghai');
error_reporting(0);
require_once $_SERVER["DOCUMENT_ROOT"]."/config.php";
require_once $_SERVER["DOCUMENT_ROOT"]."/xshop/config.php";


//读取店铺设置开始
$WX_RET_DATA = json_decode(json_encode(simplexml_load_string($GLOBALS['HTTP_RAW_POST_DATA'], 'SimpleXMLElement', LIBXML_NOCDATA)), true);
$wxoid = $WX_RET_DATA['attach'];
$Z = new CONFIG;
$order = $Z->_getOneBy('cz_order','out_trade_no',$wxoid);
$_SESSION['shopConfig'] = getShopsetByOrder($order);
//file_put_contents(dirname(__FILE__)."/logs/notify-recieved.".time().".txt", var_export($WX_RET_DATA,1));
//file_put_contents(dirname(__FILE__)."/logs/notify-order.".time().".txt", var_export($order,1));
//file_put_contents(dirname(__FILE__)."/logs/notify-shopConfig.".time().".txt", var_export($_SESSION['shopConfig'],1));
//读取店铺设置结束

require_once "lib/WxPay.Api.php";
require_once 'lib/WxPay.Notify.php';
require_once 'unit/log.php';

//初始化日志
$logHandler= new CLogFileHandler("./logs/".date('Y-m-d').'.log');
$log = Log::Init($logHandler, 15);

class PayNotifyCallBack extends WxPayNotify
{
	//查询订单
	public function Queryorder($transaction_id)
	{
		$input = new WxPayOrderQuery();
		$input->SetTransaction_id($transaction_id);
		$result = WxPayApi::orderQuery($input);
		//Log::DEBUG("queryOrderAfterPaid:" . json_encode($result));
		if(array_key_exists("return_code", $result)
			&& array_key_exists("result_code", $result)
			&& $result["return_code"] == "SUCCESS"
			&& $result["result_code"] == "SUCCESS")
		{
			return true;
		}
		return false;
	}
	
	//重写回调处理函数
	public function NotifyProcess($data, &$msg)
	{
		//Log::DEBUG("call back:" . json_encode($data));
		$notfiyOutput = array();
		
		if(!array_key_exists("transaction_id", $data)){
			$msg = "输入参数不正确:".var_export($data,1);
			Log::DEBUG($msg);
			return false;
		}
		//查询订单，判断订单真实性
		if(!$this->Queryorder($data["transaction_id"])){
			$msg = "订单查询失败:".var_export($data,1);
			Log::DEBUG($msg);
			return false;
		}
		//更新数据
		$Z = new CONFIG;
		$now = time();
		if( $Z->____updateField("cz_order","set trade_no='{$data["transaction_id"]}',status='1',updatetime='$now',DZ_ABLE_TX='1' where status=0 and out_trade_no='{$data["attach"]}';") ){
			$d = $Z->_getOneBy("cz_order",'out_trade_no',$data["attach"]);
			//CONFIG::errorLog(var_export($d,1),'zfb-log.sql');
			$user = $Z->_getOneBy("member","id",$d['member_id']);


			//读取用户等级
			$mclass = $Z->_getOneBy("member_class","id",$user['mcid']);
			//读取当前店主设置的全部等级
			$allClass = $Z->_getsBy("member_class","user_id",intval($user["user_id"]),"order by the_big asc");

			//看看是否充值送多少钱
			$zengsongjine = 0;
			if($mclass['charge_give_percent']>0){
				$zengsongjine = floatval($d['jine']*($mclass['charge_give_percent']/100));
			}
			$gengxin_jine = $d['jine'] + $zengsongjine;

			//更新用户余额=实际充值+赠送的金额
			$Z->____updateField("member","set `yue`=`yue`+{$gengxin_jine},updatetime='$now' where id='{$user['id']}';");
			//更新店主的充值字段memberChargeTotal==实际充值
			$Z->____updateField("user","set `memberChargeTotal`=`memberChargeTotal`+{$d['jine']},updatetime='$now' where id='{$d['user_id']}';");

			
			//检查充值的金额是否可以给客户升级，能升级就升级

			if($allClass){
				foreach ($allClass as $k => $v) {
					//像高级别等级跃进
					$now++;
					//当当前等级级别高于客户的级别时，并且充值额度达到最低升级要求，就升级一次
					if($v['the_big']>$mclass['the_big'] && $d['jine']>=$v['upgrade_min']){
						$Z->____updateField("member","set `mcid`='{$v['id']}',updatetime='{$now}' where id='{$user['id']}';");
					}
				}
			}


			return true;
		}else{
			$msg = "更新充值订单失败:".var_export($data,1);
			Log::DEBUG($msg);
			return false;
		}
		
		return true;
	}
}

//Log::DEBUG("begin notify");
$notify = new PayNotifyCallBack();
$notify->Handle(false);
?>